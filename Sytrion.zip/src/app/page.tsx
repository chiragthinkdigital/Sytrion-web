import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Philosophy from "@/components/Philosophy";
import Solutions from "@/components/Solutions";
import Industries from "@/components/Industries";
import WhySytrion from "@/components/WhySytrion";
import Founder from "@/components/Founder";
import CallToAction from "@/components/CallToAction";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <About />
      <Philosophy />
      <Solutions />
      <Industries />
      <WhySytrion />
      <Founder />
      <CallToAction />
      <Footer />
    </main>
  );
}
