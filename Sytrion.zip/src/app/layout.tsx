import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sytrion - Digital Transformation & Technology Solutions",
  description:
    "Empowering enterprises with cutting-edge technology solutions. Transform your business with AI-driven insights, cloud innovation, and digital expertise.",
  keywords: [
    "digital transformation",
    "cloud solutions",
    "AI",
    "machine learning",
    "cybersecurity",
    "technology consulting",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-white text-black">
        {children}
      </body>
    </html>
  );
}
