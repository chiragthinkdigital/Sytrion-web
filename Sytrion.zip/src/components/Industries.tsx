"use client";

import { useEffect, useRef, useState } from "react";

const industries = [
  "Shipping & Logistics (IBS & FNA)",
  "Healthcare & Life Sciences (HCLS)",
  "Insurance",
  "Digital Public Infrastructure (DPI)",
  "Travel",
  "Banking",
  "eCommerce",
];

const stats = [
  {
    type: "dots" as const,
    count: 5,
    displayValue: "5+",
    label: "Global Clients",
    subLabel: "",
    fillPercent: 0,
  },
  {
    type: "bar" as const,
    count: 40,
    displayValue: "20–40%",
    label: "Faster Documentation Processing",
    subLabel: "",
    fillPercent: 40,
  },
  {
    type: "bar" as const,
    count: 50,
    displayValue: "40–50%",
    label: "Automation & Annual Savings",
    subLabel: "RPAs / Transformation / Macro VBA",
    fillPercent: 50,
  },
  {
    type: "bar" as const,
    count: 50,
    displayValue: "50%",
    label: "Reduction in Dispute Resolution Time",
    subLabel: "",
    fillPercent: 50,
  },
  {
    type: "bar" as const,
    count: 40,
    displayValue: "40%",
    label: "Reduction in Operating Cost",
    subLabel: "",
    fillPercent: 40,
  },
];

const EASE_OUT = "cubic-bezier(0.16, 1, 0.3, 1)";
const FILL_DURATION = 1100;
const STAGGER_DELAY = 180;

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  return reduced;
}

export default function Industries() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  const reducedMotion = useReducedMotion();

  // Animated values for each stat row
  const animValues = useRef<number[]>(stats.map(() => 0));
  const [tick, setTick] = useState(0);
  const animFrame = useRef<number>(0);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Count-up animation
  useEffect(() => {
    if (!inView || reducedMotion) {
      if (reducedMotion && inView) {
        animValues.current = stats.map((s) => s.count);
        setTick((t) => t + 1);
      }
      return;
    }

    const startTime = performance.now();

    function animate(now: number) {
      const elapsed = now - startTime;
      let anyRunning = false;

      stats.forEach((stat, i) => {
        const rowDelay = i * STAGGER_DELAY;
        const rowElapsed = Math.max(0, elapsed - rowDelay);
        const progress = Math.min(1, rowElapsed / FILL_DURATION);
        const easedProgress = easeOutCubic(progress);
        animValues.current[i] = Math.round(easedProgress * stat.count);
        if (progress < 1) anyRunning = true;
      });

      setTick((t) => t + 1);

      if (anyRunning) {
        animFrame.current = requestAnimationFrame(animate);
      }
    }

    animFrame.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animFrame.current);
  }, [inView, reducedMotion]);

  const barTransition = reducedMotion
    ? "opacity 0.5s ease"
    : `width ${FILL_DURATION}ms ${EASE_OUT}`;

  return (
    <>
      <style>{`
        .dash-stats-band {
          position: relative;
          overflow: hidden;
        }
        .dash-stats-band::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image:
            radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }
        .dash-stats-grid {
          display: flex;
          flex-direction: column;
          gap: 28px;
          position: relative;
        }
        .dash-row {
          display: grid;
          grid-template-columns: 280px 1fr 100px;
          align-items: center;
          gap: 24px;
          opacity: 0;
          transform: translateY(16px);
          transition: opacity 0.5s ease, transform 0.5s ease;
        }
        .dash-row.dash-in-view {
          opacity: 1;
          transform: translateY(0);
        }
        .dash-row:hover .dash-value {
          transform: scale(1.05);
        }
        .dash-row:hover .bar-fill {
          filter: brightness(1.15);
        }
        .dash-row:hover .bar-track {
          box-shadow: 0 0 16px rgba(170,191,3,0.12);
        }
        .dash-label {
          font-size: 15px;
          font-weight: 500;
          color: #DCDECD;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          line-height: 1.3;
        }
        .dash-sublabel {
          font-size: 12px;
          font-weight: 400;
          color: rgba(207,207,207,0.5);
          text-transform: none;
          letter-spacing: 0;
          margin-top: 4px;
        }
        .bar-track {
          position: relative;
          height: 10px;
          background: rgba(255,255,255,0.06);
          border-radius: 999px;
          overflow: hidden;
          transition: box-shadow 0.3s ease;
        }
        .bar-fill {
          position: absolute;
          top: 0;
          left: 0;
          height: 100%;
          background: linear-gradient(93deg, #AABF03 0%, #B5D201 100%);
          border-radius: 999px;
          transition: ${barTransition};
          will-change: width;
        }
        .bar-ticks {
          position: absolute;
          inset: 0;
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0 2px;
          pointer-events: none;
        }
        .bar-ticks span {
          width: 1px;
          height: 6px;
          background: rgba(255,255,255,0.08);
          border-radius: 1px;
        }
        .dash-value {
          font-size: 26px;
          font-weight: 700;
          color: #AABF03;
          text-align: right;
          transition: transform 0.25s ease;
          font-variant-numeric: tabular-nums;
        }

        /* Dots row */
        .dots-row {
          display: grid;
          grid-template-columns: 280px 1fr 100px;
          align-items: center;
          gap: 24px;
          opacity: 0;
          transform: translateY(16px);
          transition: opacity 0.5s ease, transform 0.5s ease;
        }
        .dots-row.dash-in-view {
          opacity: 1;
          transform: translateY(0);
        }
        .dots-container {
          display: flex;
          gap: 10px;
          align-items: center;
        }
        .dot {
          width: 14px;
          height: 14px;
          border-radius: 50%;
          background: rgba(255,255,255,0.08);
          transition: background 0.4s ease, transform 0.4s ease, box-shadow 0.4s ease;
        }
        .dot.dot-filled {
          background: #AABF03;
          box-shadow: 0 0 8px rgba(170,191,3,0.3);
        }
        .dots-row:hover .dot.dot-filled {
          transform: scale(1.15);
        }

        @media (max-width: 900px) {
          .dash-row,
          .dots-row {
            grid-template-columns: 1fr;
            gap: 8px;
          }
          .dash-value {
            text-align: left;
          }
          .bar-track {
            max-width: 100%;
          }
        }
        @media (max-width: 768px) {
          .industries-stats-band {
            padding: 60px 20px !important;
          }
        }
      `}</style>

      {/* ── Main Section ─────────────────────────────────────── */}
      <section
        className="industries-section"
        style={{
          width: "100%",
          background: "#F8F8F8",
          padding: "100px 80px",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          {/* Header */}
          <div style={{ textAlign: "center", marginBottom: "60px" }}>
            <span
              style={{
                display: "inline-block",
                background: "#AABF03",
                color: "#000000",
                padding: "8px 24px",
                borderRadius: "999px",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "1px",
                textTransform: "uppercase",
                marginBottom: "24px",
              }}
            >
              Industries We Serve
            </span>
            <h2
              style={{
                fontSize: "clamp(32px, 5vw, 48px)",
                fontWeight: 700,
                color: "#000000",
                lineHeight: 1.2,
                marginBottom: "24px",
              }}
            >
              Delivering Expertise Across Industries
            </h2>
            <p
              style={{
                fontSize: "18px",
                fontWeight: 400,
                color: "#5A5D66",
                lineHeight: 1.7,
                maxWidth: "750px",
                margin: "0 auto",
              }}
            >
              Every industry presents unique opportunities and operational
              challenges. Our deep domain expertise enables us to design
              intelligent solutions that address industry-specific complexities
              while maintaining the highest standards of quality, security, and
              operational excellence.
            </p>
          </div>

          {/* Pills */}
          <div className="industries-pills">
            {industries.map((industry) => (
              <span key={industry} className="industry-pill">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                  <polyline points="22 4 12 14.01 9 11.01" />
                </svg>
                {industry}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Stats Dashboard Band ─────────────────────────────── */}
      <section
        ref={sectionRef}
        className="industries-stats-band dash-stats-band"
        style={{
          width: "100%",
          background: "#000000",
          padding: "80px 80px",
        }}
      >
        <div style={{ maxWidth: "960px", margin: "0 auto" }}>
          {/* Section heading */}
          <h3
            style={{
              fontSize: "clamp(24px, 3vw, 32px)",
              fontWeight: 700,
              color: "#FFFFFF",
              marginBottom: "48px",
              textAlign: "center",
            }}
          >
            Delivering Outcomes
          </h3>

          <div className="dash-stats-grid">
            {stats.map((stat, i) => {
              const isDots = stat.type === "dots";
              const animVal = animValues.current[i];
              const showFilled = inView && !reducedMotion
                ? animVal
                : inView && reducedMotion
                  ? stat.count
                  : 0;
              const fillWidth = inView && !reducedMotion
                ? (animVal / stat.count) * stat.fillPercent
                : inView && reducedMotion
                  ? stat.fillPercent
                  : 0;

              return isDots ? (
                <div
                  key={stat.label}
                  className={`dots-row ${inView ? "dash-in-view" : ""}`}
                  style={{
                    transitionDelay: `${i * STAGGER_DELAY}ms`,
                  }}
                  role="group"
                  aria-label={stat.label}
                >
                  <div>
                    <div className="dash-label">{stat.label}</div>
                  </div>
                  <div className="dots-container">
                    {Array.from({ length: stat.count }).map((_, d) => (
                      <div
                        key={d}
                        className={`dot ${
                          showFilled > d ? "dot-filled" : ""
                        }`}
                        style={
                          !reducedMotion
                            ? { transitionDelay: `${i * STAGGER_DELAY + d * 150}ms` }
                            : undefined
                        }
                      />
                    ))}
                  </div>
                  <div className="dash-value" aria-label={`${stat.displayValue} ${stat.label}`}>
                    {stat.displayValue}
                  </div>
                </div>
              ) : (
                <div
                  key={stat.label}
                  className={`dash-row ${inView ? "dash-in-view" : ""}`}
                  style={{
                    transitionDelay: `${i * STAGGER_DELAY}ms`,
                  }}
                  role="group"
                  aria-label={stat.label}
                >
                  <div>
                    <div className="dash-label">{stat.label}</div>
                    {stat.subLabel && (
                      <div className="dash-sublabel">{stat.subLabel}</div>
                    )}
                  </div>
                  <div
                    className="bar-track"
                    role="progressbar"
                    aria-valuenow={fillWidth}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-label={`${stat.label}: ${stat.displayValue}`}
                  >
                    <div
                      className="bar-fill"
                      style={{
                        width: inView ? `${stat.fillPercent}%` : "0%",
                        transitionDelay: !reducedMotion ? `${i * STAGGER_DELAY}ms` : "0ms",
                      }}
                    />
                    <div className="bar-ticks">
                      <span />
                      <span />
                      <span />
                      <span />
                      <span />
                    </div>
                  </div>
                  <div
                    className="dash-value"
                    aria-label={`${stat.displayValue} ${stat.label}`}
                  >
                    {inView ? (
                      stat.displayValue === "5+" ? (
                        <>{animValues.current[i]}+</>
                      ) : (
                        <>{animValues.current[i]}%</>
                      )
                    ) : (
                      "—"
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <style>{`
        .industry-pill {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 12px 24px;
          border-radius: 50px;
          border: 1px solid #DCDECD;
          background: #FFFFFF;
          font-size: 15px;
          font-weight: 500;
          color: #000000;
          cursor: pointer;
          transition: background 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }
        .industry-pill:hover {
          background: #AABF03;
          color: #FFFFFF;
          border-color: #AABF03;
        }
        .industry-pill svg {
          flex-shrink: 0;
        }
        .industries-pills {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          gap: 14px;
        }
      `}</style>
    </>
  );
}
