"use client";

export default function Founder() {
  return (
    <>
      <style>{`
        .founder-columns {
          display: flex;
          align-items: center;
          gap: 60px;
        }
        .founder-photo-block {
          background: #AABF03;
          border-radius: 24px;
          padding: 30px;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .founder-avatar {
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: #5A5D66;
          border: 4px solid rgba(255,255,255,0.5);
          box-shadow: 0 8px 32px rgba(0,0,0,0.15);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .founder-quote-mark {
          font-size: 60px;
          font-weight: 700;
          color: transparent;
          -webkit-text-stroke: 2px #AABF03;
          line-height: 1;
          margin-bottom: 8px;
          user-select: none;
        }
        .founder-quote-mark-end {
          font-size: 60px;
          font-weight: 700;
          color: transparent;
          -webkit-text-stroke: 2px #AABF03;
          line-height: 1;
          margin-top: 8px;
          user-select: none;
          text-align: right;
        }
        .founder-quote-block {
          border-left: 4px solid #AABF03;
          padding-left: 24px;
        }
        @media (max-width: 1024px) {
          .founder-columns {
            flex-direction: column;
            text-align: center;
          }
          .founder-quote-block {
            text-align: center;
            border-left: none;
            padding-left: 0;
            border-top: 4px solid #AABF03;
            padding-top: 24px;
            margin-top: 20px;
          }
          .founder-quote-mark {
            text-align: center;
          }
        }
        @media (max-width: 768px) {
          .founder-section {
            padding: 60px 20px !important;
          }
          .founder-heading {
            font-size: 26px !important;
          }
          .founder-quote-mark,
          .founder-quote-mark-end {
            font-size: 40px !important;
            text-align: center;
          }
        }
      `}</style>

      <section
        className="founder-section"
        style={{
          width: "100%",
          background: "#FFFFFF",
          padding: "100px 80px",
        }}
      >
        <div
          className="founder-columns"
          style={{ maxWidth: "1200px", margin: "0 auto" }}
        >
          {/* Left — Photo Block */}
          <div style={{ flex: "0 0 35%" }}>
            <div className="founder-photo-block">
              <div className="founder-avatar">
                <span
                  style={{
                    fontSize: "72px",
                    fontWeight: 700,
                    color: "#FFFFFF",
                    lineHeight: 1,
                  }}
                >
                  S
                </span>
              </div>
              <div style={{ marginTop: "24px", textAlign: "center" }}>
                <div
                  style={{
                    fontSize: "18px",
                    fontWeight: 700,
                    color: "#000000",
                    marginBottom: "6px",
                  }}
                >
                  [Founder Name]
                </div>
                <div
                  style={{
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#5A5D66",
                  }}
                >
                  Founder, Sytrion Data Labs Pvt. Ltd.
                </div>
              </div>
            </div>
          </div>

          {/* Right — Message */}
          <div style={{ flex: "0 0 65%" }}>
            {/* Badge */}
            <span
              style={{
                display: "inline-block",
                background: "#AABF03",
                color: "#000000",
                padding: "8px 24px",
                borderRadius: "999px",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "1px",
                textTransform: "uppercase",
                marginBottom: "20px",
              }}
            >
              Founder's Message
            </span>

            {/* Heading */}
            <h2
              className="founder-heading"
              style={{
                fontSize: "32px",
                fontWeight: 700,
                color: "#000000",
                lineHeight: 1.3,
                marginBottom: "0",
              }}
            >
              Building Businesses That Create Lasting Impact.
            </h2>

            {/* Quote block */}
            <div className="founder-quote-block">
              {/* Decorative quote mark */}
              <div className="founder-quote-mark">&ldquo;</div>

              {/* Paragraph 1 */}
              <p
                style={{
                  fontSize: "19px",
                  fontWeight: 400,
                  color: "#5A5D66",
                  lineHeight: 1.7,
                  fontStyle: "italic",
                  margin: 0,
                }}
              >
                Sytrion was founded with a simple yet ambitious vision — to help
                organizations harness the power of intelligence, technology, and
                operational excellence to build stronger businesses while
                creating meaningful opportunities for people.
              </p>

              {/* Paragraph 2 */}
              <p
                style={{
                  fontSize: "19px",
                  fontWeight: 400,
                  color: "#5A5D66",
                  lineHeight: 1.7,
                  fontStyle: "italic",
                  marginTop: "24px",
                }}
              >
                We believe sustainable success is achieved when innovation serves
                a greater purpose. Every solution we deliver is designed not only
                to transform business performance but also to contribute
                positively to the communities and industries we serve.
              </p>

              {/* End quote mark */}
              <div className="founder-quote-mark-end">&rdquo;</div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
