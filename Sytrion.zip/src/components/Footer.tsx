"use client";

import Image from "next/image";

const socialIcons = [
  {
    name: "LinkedIn",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
        <rect x="2" y="9" width="4" height="12" />
        <circle cx="4" cy="4" r="2" />
      </svg>
    ),
  },
  {
    name: "Twitter",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 4l11.733 16h4.267l-11.733-16z" />
        <path d="M4 20l6.768-6.768m2.46-2.46L20 4" />
      </svg>
    ),
  },
];

export default function Footer() {
  return (
    <>
      <style>{`
        .footer-grid {
          display: grid;
          grid-template-columns: 35% 20% 20% 25%;
          gap: 40px;
        }
        .footer-heading {
          font-size: 13px;
          font-weight: 700;
          color: #000000;
          text-transform: uppercase;
          letter-spacing: 1px;
          margin-bottom: 20px;
        }
        .footer-link {
          color: #5A5D66;
          font-size: 14px;
          text-decoration: none;
          line-height: 2.2;
          transition: color 0.2s ease;
        }
        .footer-link:hover {
          color: #AABF03;
        }
        .social-icon {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          border: 1px solid rgba(0,0,0,0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #5A5D66;
          cursor: pointer;
          transition: border-color 0.2s ease, color 0.2s ease, background 0.2s ease;
        }
        .social-icon:hover {
          border-color: #AABF03;
          color: #AABF03;
          background: rgba(170,191,3,0.08);
        }
        .contact-item {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 14px;
          color: #5A5D66;
          font-size: 14px;
        }
        .contact-icon {
          color: #AABF03;
          flex-shrink: 0;
        }
        .footer-bottom {
          border-top: 1px solid rgba(0,0,0,0.1);
          margin-top: 60px;
          padding-top: 24px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .footer-bottom-link {
          color: #5A5D66;
          font-size: 13px;
          text-decoration: none;
          transition: color 0.2s ease;
        }
        .footer-bottom-link:hover {
          color: #AABF03;
        }
        .footer-dot {
          color: #5A5D66;
          margin: 0 8px;
          font-size: 13px;
        }
        @media (max-width: 1024px) {
          .footer-grid {
            grid-template-columns: 1fr 1fr;
          }
        }
        @media (max-width: 768px) {
          .footer-section {
            padding: 50px 20px 20px !important;
          }
          .footer-grid {
            grid-template-columns: 1fr;
            text-align: center;
          }
          .social-icons {
            justify-content: center;
          }
          .footer-bottom {
            flex-direction: column;
            gap: 12px;
            text-align: center;
          }
        }
      `}</style>

      <footer
        className="footer-section"
        style={{
          width: "100%",
          background: "#F8F8F8",
          padding: "80px 80px 30px",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div className="footer-grid">
            {/* Column 1 — Brand */}
            <div>
              {/* Logo placeholder — white monochrome */}
              <div
                style={{
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Image
                  src="/Sytrion-Logo-3.jpg"
                  alt="Sytrion Logo"
                  width={200}
                  height={52}
                  style={{ height: "auto" }}
                />
              </div>

              <p
                style={{
                  marginTop: "28px",
                  fontSize: "17px",
                  fontWeight: 700,
                  color: "#AABF03",
                  lineHeight: 1.4,
                  textAlign: "left",
                }}
              >
                Engineering Intelligent Operations<br />for a Smarter World.
              </p>

              <p
                style={{
                  marginTop: "12px",
                  fontSize: "14px",
                  fontWeight: 400,
                  color: "#5A5D66",
                  lineHeight: 1.7,
                  maxWidth: "320px",
                }}
              >
                Sytrion Data Labs is an AI-powered intelligent operations
                company helping organizations transform business processes
                through automation, data intelligence, operational excellence,
                and technology-driven innovation.
              </p>

              <div
                className="social-icons"
                style={{
                  display: "flex",
                  gap: "12px",
                  marginTop: "24px",
                }}
              >
                {socialIcons.map((social) => (
                  <div key={social.name} className="social-icon">
                    {social.icon}
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2 — Quick Links */}
            <div>
              <h4 className="footer-heading">Quick Links</h4>
              <nav style={{ display: "flex", flexDirection: "column" }}>
                {["About", "Our Solutions", "Industries We Serve", "Why Sytrion", "Founder's Message"].map(
                  (link) => (
                    <a key={link} href="#" className="footer-link">
                      {link}
                    </a>
                  )
                )}
              </nav>
            </div>

            {/* Column 3 — Solutions */}
            <div>
              <h4 className="footer-heading">Solutions</h4>
              <nav style={{ display: "flex", flexDirection: "column" }}>
                {[
                  "AI Automation & Agentic AI",
                  "Intelligent Operations",
                  "Data Engineering",
                  "Analytics & BI",
                  "Shipping & Logistics",
                  "Healthcare Operations",
                ].map((link) => (
                  <a key={link} href="#" className="footer-link">
                    {link}
                  </a>
                ))}
              </nav>
            </div>

            {/* Column 4 — Contact */}
            <div>
              <h4 className="footer-heading">Get in Touch</h4>

              <div className="contact-item">
                <span className="contact-icon">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                  </svg>
                </span>
                <span>[email placeholder]</span>
              </div>

              <div className="contact-item">
                <span className="contact-icon">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                </span>
                <span>[phone placeholder]</span>
              </div>

              <div className="contact-item">
                <span className="contact-icon">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </span>
                <span>[address placeholder]</span>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="footer-bottom">
              <span style={{ color: "#5A5D66", fontSize: "13px" }}>
              &copy; 2026 Sytrion Data Labs Pvt. Ltd. All rights reserved.
            </span>
            <div style={{ display: "flex", alignItems: "center" }}>
              <a href="#" className="footer-bottom-link">Privacy Policy</a>
              <span className="footer-dot">&middot;</span>
              <a href="#" className="footer-bottom-link">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
