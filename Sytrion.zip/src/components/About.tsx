"use client";

import { DotLottieReact } from "@lottiefiles/dotlottie-react";

export default function About() {
  return (
    <section
      id="about"
      style={{
        width: "100%",
        background: "#F8F8F8",
        padding: "100px 80px",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          gap: "80px",
        }}
      >
        {/* Left — Text */}
        <div style={{ flex: 1 }}>
          {/* Badge */}
          <span
            style={{
              display: "inline-block",
              background: "#AABF03",
              color: "#000000",
              padding: "8px 24px",
              borderRadius: "999px",
              fontSize: "13px",
              fontWeight: 700,
              letterSpacing: "1px",
              textTransform: "uppercase",
              marginBottom: "40px",
            }}
          >
            About Sytrion
          </span>

          {/* Subheading */}
          <h2
            style={{
              fontSize: "clamp(32px, 5vw, 48px)",
              fontWeight: 700,
              color: "#000000",
              lineHeight: 1.2,
              marginBottom: "24px",
            }}
          >
            Intelligence with Purpose.
          </h2>

          {/* Intro line */}
          <p
            style={{
              fontSize: "18px",
              fontWeight: 400,
              color: "#5A5D66",
              lineHeight: 1.7,
              marginBottom: "40px",
            }}
          >
            Technology has the power to redefine industries, but only when it
            solves real business challenges.
          </p>

          {/* Divider */}
          <div
            style={{
              width: "60px",
              height: "3px",
              background: "#AABF03",
              borderRadius: "2px",
              marginBottom: "40px",
            }}
          />

          {/* Body paragraph 1 */}
          <p
            style={{
              fontSize: "17px",
              fontWeight: 400,
              color: "#5A5D66",
              lineHeight: 1.8,
              marginBottom: "20px",
            }}
          >
            At Sytrion Data Labs, we combine intelligent technologies with
            operational excellence to simplify complexity, improve productivity,
            and create sustainable business value. Every engagement is designed to
            help organizations operate smarter, innovate faster, and adapt
            confidently in an evolving digital world.
          </p>

          {/* Body paragraph 2 */}
          <p
            style={{
              fontSize: "17px",
              fontWeight: 400,
              color: "#5A5D66",
              lineHeight: 1.8,
            }}
          >
            Our purpose extends beyond business transformation. We aspire to
            create opportunities, empower people, and contribute to building a
            more connected and intelligent future.
          </p>
        </div>

        {/* Right — Lottie animation */}
        <div
          style={{
            flex: 1,
            position: "relative",
            minHeight: "650px",
          }}
        >
          <DotLottieReact
            src="/about.json"
            loop
            autoplay
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
            width: "150%",
            height: "100%",
            }}
          />
        </div>
      </div>
    </section>
  );
}
