"use client";

import { useEffect, useRef, useState, useCallback, useSyncExternalStore } from "react";

const solutions = [
  {
    number: "01",
    title: "AI Automation & Agentic AI",
    description:
      "Empowering enterprises with intelligent automation, cognitive workflows, and AI-driven decision-making to transform operational performance.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-1v1a4 4 0 0 1-8 0v-1H7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4z" />
        <circle cx="9" cy="10" r="1" fill="currentColor" />
        <circle cx="15" cy="10" r="1" fill="currentColor" />
        <path d="M9.5 15a3.5 3.5 0 0 0 5 0" />
      </svg>
    ),
  },
  {
    number: "02",
    title: "Intelligent Operations (RPAs)",
    description:
      "Delivering technology-enabled managed operations that combine skilled professionals, standardized processes, and intelligent automation to achieve measurable business outcomes.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
      </svg>
    ),
  },
  {
    number: "03",
    title: "Data Engineering",
    description:
      "Building trusted data ecosystems through data processing, enrichment, validation, migration, and intelligent data management.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="12" cy="5" rx="9" ry="3" />
        <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
        <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
      </svg>
    ),
  },
  {
    number: "04",
    title: "Analytics & Business Intelligence",
    description:
      "Transforming enterprise data into actionable insights through dashboards, reporting, predictive analytics, and decision intelligence.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="20" x2="18" y2="10" />
        <line x1="12" y1="20" x2="12" y2="4" />
        <line x1="6" y1="20" x2="6" y2="14" />
      </svg>
    ),
  },
  {
    number: "05",
    title: "Shipping & Logistics Solutions",
    description:
      "Digitally transforming freight forwarding, shipping operations, customs documentation, and supply chain support through intelligent operational services.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 20h20" />
        <path d="M5 20V8l7-4 7 4v12" />
        <path d="M9 20v-6h6v6" />
        <path d="M10 12h4" />
      </svg>
    ),
  },
  {
    number: "06",
    title: "Healthcare Operations",
    description:
      "Enhancing healthcare administration through claims management, document intelligence, workflow automation, and secure operational support.",
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
      </svg>
    ),
  },
];

const CARD_WIDTH = 310;
const CARD_GAP = 28;

function SolutionCard({
  item,
  isActive,
}: {
  item: (typeof solutions)[number];
  isActive: boolean;
}) {
  return (
    <div
      className={`solutions-card-h${isActive ? " active" : ""}`}
    >
      <span className="card-number">{item.number}</span>
      <div className="icon-circle">{item.icon}</div>
      <h3
        style={{
          fontSize: "18px",
          fontWeight: 700,
          color: "#000000",
          marginTop: "20px",
          marginBottom: "10px",
        }}
      >
        {item.title}
      </h3>
      <p
        style={{
          fontSize: "14px",
          fontWeight: 400,
          color: "#5A5D66",
          lineHeight: 1.6,
          flex: 1,
        }}
      >
        {item.description}
      </p>
    </div>
  );
}

export default function Solutions() {
  const outerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const currentXRef = useRef(0);
  const targetXRef = useRef(0);
  const rafRef = useRef<number>(0);
  const prevActiveRef = useRef(-1);
  const [scrollRunway, setScrollRunway] = useState(0);

  const prefersReduced = useSyncExternalStore(
    (cb) => {
      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      mq.addEventListener("change", cb);
      return () => mq.removeEventListener("change", cb);
    },
    () => window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    () => false
  );

  const isMobile = useSyncExternalStore(
    (cb) => {
      const check = () => cb();
      check();
      window.addEventListener("resize", check);
      return () => window.removeEventListener("resize", check);
    },
    () => window.innerWidth < 768,
    () => false
  );

  const cardCount = solutions.length;

  const computeRunway = useCallback(() => {
    const vw = window.innerWidth;
    const trackWidth = cardCount * CARD_WIDTH + (cardCount - 1) * CARD_GAP;
    const sidePadding = Math.min(80, (vw - 1200) / 2 + 80);
    const visibleWidth = Math.min(vw - sidePadding * 2, 1200);
    const travel = Math.max(0, trackWidth - visibleWidth);
    return Math.ceil(travel * 2);
  }, [cardCount]);

  useEffect(() => {
    const onResize = () => setScrollRunway(computeRunway());
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [computeRunway]);

  useEffect(() => {
    if (isMobile || prefersReduced) return;

    const track = trackRef.current;
    const outer = outerRef.current;
    const progressDots = progressRef.current;
    if (!track || !outer || !progressDots) return;

    const cards = track.querySelectorAll(".solutions-card-h");
    const dots = progressDots.querySelectorAll(".solutions-progress-dot");

    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    let ticking = false;

    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      rafRef.current = requestAnimationFrame(() => {
        ticking = false;

        const rect = outer.getBoundingClientRect();
        const vh = window.innerHeight;
        const scrollable = outer.offsetHeight - vh;
        if (scrollable <= 0) return;

        const rawProgress = Math.max(0, Math.min(1, -rect.top / scrollable));

        const trackWidth = track.scrollWidth;
        const vw = window.innerWidth;
        const sidePadding = Math.min(80, (vw - 1200) / 2 + 80);
        const visibleWidth = Math.min(vw - sidePadding * 2, 1200);
        const centerOffset = (visibleWidth - CARD_WIDTH) / 2;
        const maxTranslate = Math.max(0, trackWidth - visibleWidth + centerOffset);

        const startX = centerOffset;
        const endX = -(maxTranslate - centerOffset);
        targetXRef.current = startX + rawProgress * (endX - startX);
        currentXRef.current = lerp(currentXRef.current, targetXRef.current, 0.1);

        track.style.transform = `translateX(${currentXRef.current}px)`;

        const progress = rawProgress;
        const idx = Math.min(
          cardCount - 1,
          Math.floor(progress * cardCount)
        );

        if (idx !== prevActiveRef.current) {
          prevActiveRef.current = idx;
          cards.forEach((card, i) => {
            card.classList.toggle("active", i === idx);
          });
          dots.forEach((dot, i) => {
            dot.classList.toggle("active", i === idx);
          });
        }
      });
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(rafRef.current);
    };
  }, [isMobile, prefersReduced, cardCount]);

  const usePin = !isMobile && !prefersReduced;

  return (
    <>
      <style>{`
        .solutions-card-h {
          background: #FFFFFF;
          border: 0.5px solid #DCDECD;
          border-radius: 12px;
          padding: 28px;
          min-width: ${CARD_WIDTH}px;
          max-width: ${CARD_WIDTH}px;
          height: 280px;
          display: flex;
          flex-direction: column;
          position: relative;
          flex-shrink: 0;
          transition: border-color 0.4s ease, transform 0.4s ease;
        }
        .solutions-card-h.active {
          border-top: 3px solid #AABF03;
          transform: scale(1.03);
        }
        .solutions-card-h .icon-circle {
          width: 54px;
          height: 54px;
          border-radius: 50%;
          background: #DCDECD;
          color: #AABF03;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.3s ease, color 0.3s ease;
          flex-shrink: 0;
        }
        .solutions-card-h.active .icon-circle {
          background: rgba(170, 191, 3, 0.15);
        }
        .solutions-card-h .card-number {
          position: absolute;
          top: 28px;
          right: 32px;
          font-size: 30px;
          font-weight: 500;
          color: #DCDECD;
          line-height: 1;
        }
        .solutions-card-h.active .card-number {
          color: #B5D201;
        }
        .solutions-progress-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #DCDECD;
          transition: background 0.3s ease, transform 0.3s ease;
        }
        .solutions-progress-dot.active {
          background: #AABF03;
          transform: scale(1.4);
        }
        .solutions-mobile-track {
          display: flex;
          gap: 24px;
          overflow-x: auto;
          scroll-snap-type: x mandatory;
          -webkit-overflow-scrolling: touch;
          padding: 0 20px 20px;
          scrollbar-width: none;
        }
        .solutions-mobile-track::-webkit-scrollbar {
          display: none;
        }
        .solutions-mobile-track .solutions-card-h {
          scroll-snap-align: start;
          min-width: 280px;
          max-width: 280px;
        }
      `}</style>

      <section
        className="solutions-section"
        style={{
          width: "100%",
          background: "#F5F6F0",
          padding: "40px 80px 0",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>

        {/* Mobile: heading outside sticky */}
        {isMobile && (
          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <span
              style={{
                display: "inline-block",
                background: "#AABF03",
                color: "#000000",
                padding: "8px 24px",
                borderRadius: "999px",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "1px",
                textTransform: "uppercase",
                marginBottom: "16px",
              }}
            >
              Our Solutions
            </span>
            <h2
              style={{
                fontSize: "clamp(28px, 5vw, 40px)",
                fontWeight: 700,
                color: "#000000",
                lineHeight: 1.2,
                marginBottom: "12px",
              }}
            >
              Intelligent Solutions. Meaningful Outcomes.
            </h2>
            <p
              style={{
                fontSize: "16px",
                fontWeight: 400,
                color: "#5A5D66",
                lineHeight: 1.6,
                maxWidth: "750px",
                margin: "0 auto",
              }}
            >
              Every business faces unique operational challenges. Our integrated
              portfolio of technology-enabled services helps organizations
              optimize operations, unlock efficiencies, and accelerate digital
              transformation.
            </p>
          </div>
        )}

        {/* Mobile: native swipeable scroll */}
        {isMobile && (
          <div className="solutions-mobile-track">
            {solutions.map((item) => (
              <SolutionCard key={item.number} item={item} isActive={false} />
            ))}
          </div>
        )}

        {/* Desktop: pinned horizontal scroll */}
        {usePin && (
          <div
            ref={outerRef}
            style={{ height: `${scrollRunway}px`, position: "relative" }}
          >
            <div
              style={{
                position: "sticky",
                top: 0,
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  maxWidth: "1200px",
                  margin: "0 auto",
                  width: "100%",
                  padding: "0 80px",
                }}
              >
                {/* Heading inside sticky */}
                <div style={{ textAlign: "center", marginBottom: "12px" }}>
                  <span
                    style={{
                      display: "inline-block",
                      background: "#AABF03",
                      color: "#000000",
                      padding: "6px 20px",
                      borderRadius: "999px",
                      fontSize: "12px",
                      fontWeight: 700,
                      letterSpacing: "1px",
                      textTransform: "uppercase",
                      marginBottom: "10px",
                    }}
                  >
                    Our Solutions
                  </span>
                  <h2
                    style={{
                      fontSize: "clamp(28px, 4vw, 38px)",
                      fontWeight: 700,
                      color: "#000000",
                      lineHeight: 1.2,
                      marginBottom: "8px",
                    }}
                  >
                    Intelligent Solutions. Meaningful Outcomes.
                  </h2>
                  <p
                    style={{
                      fontSize: "15px",
                      fontWeight: 400,
                      color: "#5A5D66",
                      lineHeight: 1.5,
                      maxWidth: "650px",
                      margin: "0 auto",
                    }}
                  >
                    Every business faces unique operational challenges. Our integrated
                    portfolio of technology-enabled services helps organizations
                    optimize operations, unlock efficiencies, and accelerate digital
                    transformation.
                  </p>
                </div>
                <div
                  ref={trackRef}
                  style={{
                    display: "flex",
                    gap: `${CARD_GAP}px`,
                    willChange: "transform",
                  }}
                >
                  {solutions.map((item, i) => (
                    <SolutionCard
                      key={item.number}
                      item={item}
                      isActive={i === 0}
                    />
                  ))}
                </div>

                <div
                  ref={progressRef}
                  style={{
                    display: "flex",
                    gap: "12px",
                    justifyContent: "center",
                    marginTop: "20px",
                  }}
                >
                  {solutions.map((_, i) => (
                    <div
                      key={i}
                      className={`solutions-progress-dot${i === 0 ? " active" : ""}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
      </section>
    </>
  );
}
