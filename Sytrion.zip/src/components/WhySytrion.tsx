"use client";

const bentoCards = [
  {
    id: 1,
    span: 7,
    featured: true,
    title: "AI-First Thinking",
    description:
      "Embedding intelligence into every process to improve efficiency and accelerate innovation.",
    icon: (
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-1v1a4 4 0 0 1-8 0v-1H7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4z" />
        <circle cx="9" cy="10" r="1" fill="currentColor" />
        <circle cx="15" cy="10" r="1" fill="currentColor" />
        <path d="M9.5 15a3.5 3.5 0 0 0 5 0" />
      </svg>
    ),
  },
  {
    id: 2,
    span: 5,
    featured: false,
    title: "Business Transformation",
    description:
      "Helping organizations modernize operations through scalable, measurable transformation initiatives.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
        <polyline points="17 6 23 6 23 12" />
      </svg>
    ),
  },
  {
    id: 3,
    span: 4,
    featured: false,
    title: "Enterprise Security",
    description:
      "Protecting critical business information with secure infrastructure, governance frameworks, and confidentiality-first practices.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    ),
  },
  {
    id: 4,
    span: 4,
    featured: false,
    title: "Scalable Delivery",
    description:
      "Flexible engagement models that grow alongside your business.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
      </svg>
    ),
  },
  {
    id: 5,
    span: 4,
    featured: false,
    title: "Customer Partnership",
    description:
      "Building long-term relationships founded on trust, transparency, collaboration, and shared success.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
  },
];

export default function WhySytrion() {
  return (
    <>
      <style>{`
        .bento-grid {
          display: grid;
          grid-template-columns: repeat(12, 1fr);
          gap: 24px;
        }
        .bento-card {
          background: #FFFFFF;
          border-radius: 16px;
          padding: 32px;
          box-shadow: 0 4px 24px rgba(0,0,0,0.05);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          position: relative;
          overflow: hidden;
        }
        .bento-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 12px 40px rgba(0,0,0,0.12);
        }
        .bento-card:hover .bento-icon {
          background: #AABF03;
          color: #FFFFFF;
        }
        .bento-card.featured {
          background: linear-gradient(135deg, rgba(170,191,3,0.08) 0%, #FFFFFF 60%);
        }
        .bento-icon {
          width: 48px;
          height: 48px;
          border-radius: 14px;
          background: rgba(170, 191, 3, 0.12);
          color: #AABF03;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.3s ease, color 0.3s ease;
        }
        .bento-card.featured .bento-icon {
          width: 64px;
          height: 64px;
          border-radius: 18px;
        }
        .bento-card.featured .bento-title {
          font-size: 24px;
        }
        .bento-card.featured .bento-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 160px;
          height: 160px;
          background: radial-gradient(circle, rgba(170,191,3,0.1) 0%, transparent 70%);
          border-radius: 50%;
          pointer-events: none;
        }
        @media (max-width: 1024px) {
          .bento-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          .bento-card {
            grid-column: span 1 !important;
          }
          .security-callout {
            flex-direction: column !important;
            gap: 40px !important;
          }
        }
        @media (max-width: 768px) {
          .bento-grid {
            grid-template-columns: 1fr;
          }
          .why-section {
            padding: 60px 20px !important;
          }
          .security-callout {
            padding: 30px !important;
          }
          .security-checklist {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>

      <section
        className="why-section"
        style={{
          width: "100%",
          background: "#F8F8F8",
          padding: "100px 80px",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>

          {/* Header */}
          <div style={{ textAlign: "center", marginBottom: "60px" }}>
            <span
              style={{
                display: "inline-block",
                background: "#AABF03",
                color: "#000000",
                padding: "8px 24px",
                borderRadius: "999px",
                fontSize: "13px",
                fontWeight: 700,
                letterSpacing: "1px",
                textTransform: "uppercase",
                marginBottom: "24px",
              }}
            >
              Why Sytrion
            </span>

            <h2
              style={{
                fontSize: "clamp(32px, 5vw, 48px)",
                fontWeight: 700,
                color: "#000000",
                lineHeight: 1.2,
                marginBottom: "24px",
              }}
            >
              A Trusted Partner for Intelligent Transformation
            </h2>

            <p
              style={{
                fontSize: "18px",
                fontWeight: 400,
                color: "#5A5D66",
                lineHeight: 1.7,
                maxWidth: "700px",
                margin: "0 auto",
              }}
            >
              Organizations choose Sytrion because we combine technological
              innovation with operational expertise to deliver meaningful
              business outcomes.
            </p>
          </div>

          {/* Bento Grid */}
          <div className="bento-grid">
            {bentoCards.map((card) => (
              <div
                key={card.id}
                className={`bento-card ${card.featured ? "featured" : ""}`}
                style={{
                  gridColumn: `span ${card.span}`,
                }}
              >
                {card.featured && <div className="bento-glow" />}
                <div className="bento-icon">{card.icon}</div>
                <h3
                  className="bento-title"
                  style={{
                    fontSize: card.featured ? "24px" : "19px",
                    fontWeight: 700,
                    color: "#000000",
                    marginTop: "20px",
                    marginBottom: "10px",
                  }}
                >
                  {card.title}
                </h3>
                <p
                  style={{
                    fontSize: "15px",
                    fontWeight: 400,
                    color: "#5A5D66",
                    lineHeight: 1.6,
                  }}
                >
                  {card.description}
                </p>
              </div>
            ))}
          </div>

          {/* ── Security Callout ─────────────────────────────── */}
          <div
            className="security-callout"
            style={{
              marginTop: "60px",
              background: "#F0F0F0",
              borderRadius: "20px",
              padding: "50px",
              display: "flex",
              gap: "60px",
              alignItems: "flex-start",
            }}
          >
            {/* Left — Text */}
            <div style={{ flex: 6 }}>
              <h3
                style={{
                  fontSize: "28px",
                  fontWeight: 700,
                  color: "#000000",
                  lineHeight: 1.3,
                  marginBottom: "20px",
                }}
              >
                Security by Design. Trust by Commitment.
              </h3>
              <p
                style={{
                  fontSize: "16px",
                  fontWeight: 400,
                  color: "#5A5D66",
                  lineHeight: 1.7,
                  maxWidth: "480px",
                }}
              >
                Protecting client information is fundamental to everything we
                do. Our delivery framework incorporates secure infrastructure,
                role-based access controls, confidentiality agreements,
                governance policies, and compliance-focused operational
                practices to ensure your business information remains protected
                throughout every engagement.
              </p>
            </div>

            {/* Right — Checklist */}
            <div style={{ flex: 4 }}>
              <span
                style={{
                  display: "block",
                  fontSize: "12px",
                  fontWeight: 700,
                  color: "#AABF03",
                  textTransform: "uppercase",
                  letterSpacing: "1px",
                  marginBottom: "20px",
                }}
              >
                Commitment Highlights
              </span>
              <div
                className="security-checklist"
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: "0 24px",
                }}
              >
                {[
                  "Secure Infrastructure",
                  "Role Based Access Controls",
                  "Confidentiality First",
                  "Business Continuity Planning",
                  "Audit-Ready Processes",
                  "Compliance-Oriented Operations",
                ].map((item) => (
                  <div
                    key={item}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      marginBottom: "18px",
                    }}
                  >
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#AABF03"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      style={{ flexShrink: 0 }}
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    <span
                      style={{
                        fontSize: "15px",
                        fontWeight: 500,
                        color: "#000000",
                      }}
                    >
                      {item}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
